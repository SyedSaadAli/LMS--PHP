<?php
// if(isset($_SESSION['Username']))
// {

// } else{
// 	header('location:../login.php');
// }
?>
 